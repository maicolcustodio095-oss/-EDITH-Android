# E.D.I.T.H. 1.0 — Android

Prototipo inicial para Android 13: interfaz oscura, reconocimiento de voz mediante el servicio del dispositivo, síntesis de voz y modo experimental para escuchar «Edith» **solo con la aplicación abierta**.

## Estado
- No incluye todavía conexión a IA, memoria ni cámara.
- La detección de «Edith» reutiliza sesiones de SpeechRecognizer: puede tener pausas y no es un detector de palabra clave permanente.
- El reconocimiento puede requerir conexión a internet y un servicio de voz instalado.
- No guardar claves API en el APK.

## Generar APK desde GitHub (sin computadora)
1. Crear repositorio privado `EDITH-Android` en GitHub.
2. Subir los archivos de este ZIP **manteniendo las carpetas**, incluida `.github/workflows/android.yml`.
3. En GitHub abrir **Actions > Compilar E.D.I.T.H. APK > Run workflow**.
4. Al terminar correctamente, abrir la ejecución y descargar el artefacto `EDITH-1.0-debug-apk`.
5. Extraer el ZIP del artefacto e instalar `app-debug.apk` en el teléfono. Android puede solicitar autorización para instalar APK desde esa aplicación.

El APK será una compilación de depuración para pruebas, no una versión publicada en Play Store. No ha sido probado en el Z2357N.
