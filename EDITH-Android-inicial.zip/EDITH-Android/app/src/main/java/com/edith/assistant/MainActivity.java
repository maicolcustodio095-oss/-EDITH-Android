package com.edith.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private TextView status, transcript;
    private boolean wakeMode = false;
    private boolean listening = false;
    private boolean ttsReady = false;
    private boolean active = false;
    private Button wakeButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(4, 13, 26));
        getWindow().setNavigationBarColor(Color.rgb(4, 13, 26));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(30, 60, 30, 24);
        root.setBackgroundColor(Color.rgb(4, 13, 26));
        TextView title = text("E.D.I.T.H.", 34, Color.rgb(75, 223, 255));
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);
        TextView sub = text("ASISTENTE PERSONAL · PROTOTIPO 1.0", 12, Color.LTGRAY);
        root.addView(sub);
        TextView orb = text("◉", 160, Color.rgb(0, 184, 230));
        root.addView(orb);
        status = text("Lista para escuchar", 19, Color.WHITE);
        root.addView(status);
        transcript = text("Pulsa el micrófono para hablar", 15, Color.LTGRAY);
        transcript.setPadding(8, 20, 8, 36);
        root.addView(transcript);
        Button mic = button("🎙  HABLAR CON EDITH");
        root.addView(mic);
        mic.setOnClickListener(v -> { wakeMode = false; startListening(); });
        wakeButton = button("ACTIVAR 'EDITH' (APP ABIERTA)");
        root.addView(wakeButton);
        wakeButton.setOnClickListener(v -> {
            wakeMode = !wakeMode;
            wakeButton.setText(wakeMode ? "DESACTIVAR ESCUCHA" : "ACTIVAR 'EDITH' (APP ABIERTA)");
            if (wakeMode) startListening(); else stopListening();
        });
        TextView foot = text("Versión de demostración · Sin conexión a IA todavía\nLa escucha por nombre requiere la app abierta.", 12, Color.LTGRAY);
        foot.setPadding(0, 32, 0, 0);
        root.addView(foot);
        setContentView(root);
        tts = new TextToSpeech(this, this);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100);
    }
    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER); return v;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(0, 112, 164)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 8, 0, 8); b.setLayoutParams(lp); return b;
    }
    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 100); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Reconocimiento de voz no disponible"); return; }
        stopRecognizerOnly();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { listening = true; status.setText(wakeMode ? "Esperando 'Edith'…" : "Escuchando…"); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { listening = false; }
            public void onError(int error) { listening = false; status.setText("Escucha detenida (" + error + ")"); if (wakeMode && active) scheduleRestart(); }
            public void onResults(Bundle b) {
                listening = false;
                ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String heard = list != null && !list.isEmpty() ? list.get(0) : "";
                transcript.setText("Escuché: " + heard);
                String lower = heard.toLowerCase(Locale.ROOT);
                if (!wakeMode || lower.contains("edith") || lower.contains("edit")) respond(heard);
                if (wakeMode && active) scheduleRestart();
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int type, Bundle b) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-DO");
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(intent);
    }
    private void scheduleRestart() { status.postDelayed(() -> { if (wakeMode && active && !listening) startListening(); }, 1300); }
    private void respond(String heard) {
        String reply = "Te escucho. Soy Edith, versión uno. Pronto podré responder con inteligencia artificial.";
        status.setText("E.D.I.T.H. respondiendo");
        if (ttsReady) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "edith-reply");
        transcript.setText("Tú: " + heard + "\n\nE.D.I.T.H.: " + reply);
    }
    private void stopRecognizerOnly() { if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; } listening = false; }
    private void stopListening() { stopRecognizerOnly(); status.setText("Escucha desactivada"); }
    @Override public void onInit(int code) { if (code == TextToSpeech.SUCCESS) { ttsReady = tts.setLanguage(new Locale("es", "DO")) >= 0; } }
    @Override protected void onResume() { super.onResume(); active = true; }
    @Override protected void onPause() { active = false; wakeMode = false; if (wakeButton != null) wakeButton.setText("ACTIVAR 'EDITH' (APP ABIERTA)"); stopListening(); super.onPause(); }
    @Override protected void onDestroy() { stopRecognizerOnly(); if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
